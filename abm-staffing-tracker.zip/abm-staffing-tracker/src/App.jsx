import { useState, useMemo, useEffect, useRef } from "react";
import {
  Users,
  Building2,
  AlertTriangle,
  Plus,
  X,
  CheckCircle2,
  Circle,
  Zap,
  Lock,
} from "lucide-react";

// ---------- Design tokens ----------
// Palette: slate base, indigo accent, status colors for coverage
// bg-slate-950 / panel-slate-900 / line-slate-800 / text-slate-200
// accent indigo-500, ok emerald-500, warn amber-500, gap rose-500

const ROLES = ["Lead", "Support", "Reviewer", "Backup", "Coordinator"];
const TIERS = ["Tier 1", "Tier 2", "Tier 3"];

// Each tier requires specific roles to be considered "covered".
// Edit these arrays to match your actual staffing model.
const ROLE_REQUIREMENTS = {
  "Tier 1": ["Lead", "Support", "Reviewer", "Coordinator"],
  "Tier 2": ["Lead", "Support"],
  "Tier 3": ["Lead"],
};

const TARGET_COVERAGE = {
  "Tier 1": ROLE_REQUIREMENTS["Tier 1"].length,
  "Tier 2": ROLE_REQUIREMENTS["Tier 2"].length,
  "Tier 3": ROLE_REQUIREMENTS["Tier 3"].length,
};

// Tier priority order for "fill biggest gaps first"
const TIER_RANK = { "Tier 1": 0, "Tier 2": 1, "Tier 3": 2 };

const initialPeople = [
  { id: "p1", name: "Calipara", role: "Lead" },
  { id: "p2", name: "Darlene Buenaventura", role: "Support" },
  { id: "p3", name: "Sean Lawrence Andrade", role: "Reviewer" },
  { id: "p4", name: "Arkin and Romawac", role: "Backup" },
  { id: "p5", name: "Yenna Cydell", role: "Coordinator" },
];

const initialAccounts = [
  { id: "a1", name: "Account A", tier: "Tier 1", assignedIds: ["p1", "p2", "p3"], manualIds: ["p1", "p2", "p3"] },
  { id: "a2", name: "Account B", tier: "Tier 1", assignedIds: ["p1"], manualIds: ["p1"] },
  { id: "a3", name: "Account C", tier: "Tier 2", assignedIds: [], manualIds: [] },
  { id: "a4", name: "Account D", tier: "Tier 3", assignedIds: ["p4"], manualIds: ["p4"] },
  { id: "a5", name: "Account E", tier: "Tier 2", assignedIds: ["p2"], manualIds: ["p2"] },
];

// Which required roles for this account are still unfilled?
function missingRoles(account, people) {
  const required = ROLE_REQUIREMENTS[account.tier] || [];
  const assignedRoles = new Set(
    account.assignedIds.map((id) => people.find((p) => p.id === id)?.role)
  );
  return required.filter((r) => !assignedRoles.has(r));
}

function coverageStatus(account, people) {
  if (account.assignedIds.length === 0) return "gap";
  const missing = missingRoles(account, people);
  if (missing.length > 0) return "under";
  const required = ROLE_REQUIREMENTS[account.tier] || [];
  if (account.assignedIds.length > required.length) return "over";
  return "ok";
}

// --- Auto-assign algorithm ---
// 1. Sort accounts: unstaffed > short-staffed, then Tier 1 > Tier 2 > Tier 3
// 2. For each account, for each missing required role, pick the person
//    with that role carrying the lowest current account load
//    (ties broken alphabetically for stable, predictable results)
// 3. Never touches manually-assigned people; only fills empty required-role slots
// 4. If no one has the needed role, the slot is left open and flagged
function autoAssign(accounts, people) {
  const load = {};
  people.forEach((p) => (load[p.id] = 0));
  accounts.forEach((a) => a.assignedIds.forEach((id) => (load[id] = (load[id] || 0) + 1)));

  const working = accounts.map((a) => ({ ...a, assignedIds: [...a.assignedIds] }));

  const order = [...working].sort((a, b) => {
    const aGap = a.assignedIds.length === 0;
    const bGap = b.assignedIds.length === 0;
    if (aGap !== bGap) return aGap ? -1 : 1;
    const aMissing = missingRoles(a, people).length;
    const bMissing = missingRoles(b, people).length;
    if (aMissing !== bMissing) return bMissing - aMissing;
    return TIER_RANK[a.tier] - TIER_RANK[b.tier];
  });

  const unfilledSlots = [];

  for (const account of order) {
    const target = working.find((a) => a.id === account.id);
    let missing = missingRoles(target, people);

    for (const role of missing) {
      const candidates = people
        .filter((p) => p.role === role && !target.assignedIds.includes(p.id))
        .sort((a, b) => (load[a.id] - load[b.id]) || a.name.localeCompare(b.name));

      if (candidates.length === 0) {
        unfilledSlots.push({ accountName: target.name, role });
        continue;
      }
      const chosen = candidates[0];
      target.assignedIds.push(chosen.id);
      load[chosen.id] = (load[chosen.id] || 0) + 1;
    }
  }

  return { accounts: working, unfilledSlots };
}

const STATUS_STYLES = {
  gap: { bar: "bg-rose-500", text: "text-rose-400", label: "Unstaffed" },
  under: { bar: "bg-amber-500", text: "text-amber-400", label: "Short-staffed" },
  ok: { bar: "bg-emerald-500", text: "text-emerald-400", label: "Covered" },
  over: { bar: "bg-indigo-400", text: "text-indigo-300", label: "Overstaffed" },
};

export default function ABMStaffingTracker() {
  const [people, setPeople] = useState(initialPeople);
  const [accounts, setAccounts] = useState(initialAccounts);
  const [filterTier, setFilterTier] = useState("All");
  const [filterStatus, setFilterStatus] = useState("All");
  const [assignOpenFor, setAssignOpenFor] = useState(null);
  const [newPersonName, setNewPersonName] = useState("");
  const [newPersonRole, setNewPersonRole] = useState(ROLES[0]);
  const [newAccountName, setNewAccountName] = useState("");
  const [newAccountTier, setNewAccountTier] = useState(TIERS[1]);
  const [showAddPerson, setShowAddPerson] = useState(false);
  const [showAddAccount, setShowAddAccount] = useState(false);
  const [autoEnabled, setAutoEnabled] = useState(true);
  const [unfilledSlots, setUnfilledSlots] = useState([]);
  const [lastAutoCount, setLastAutoCount] = useState(0);
  const skipNextAuto = useRef(false);

  const personById = useMemo(() => {
    const m = {};
    people.forEach((p) => (m[p.id] = p));
    return m;
  }, [people]);

  // Auto-run: whenever people/accounts change (and auto is on), fill gaps.
  // skipNextAuto guards against the effect re-triggering on its own output.
  useEffect(() => {
    if (!autoEnabled) return;
    if (skipNextAuto.current) {
      skipNextAuto.current = false;
      return;
    }
    const { accounts: filled, unfilledSlots: gaps } = autoAssign(accounts, people);
    const changed = filled.some(
      (a, i) => a.assignedIds.length !== accounts[i].assignedIds.length
    );
    setUnfilledSlots(gaps);
    if (changed) {
      const newlyAssigned = filled.reduce(
        (sum, a, i) => sum + (a.assignedIds.length - accounts[i].assignedIds.length),
        0
      );
      setLastAutoCount(newlyAssigned);
      skipNextAuto.current = true;
      setAccounts(filled);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [people, autoEnabled]);

  function runAutoAssignNow() {
    const { accounts: filled, unfilledSlots: gaps } = autoAssign(accounts, people);
    const newlyAssigned = filled.reduce(
      (sum, a, i) => sum + (a.assignedIds.length - accounts[i].assignedIds.length),
      0
    );
    setLastAutoCount(newlyAssigned);
    setUnfilledSlots(gaps);
    skipNextAuto.current = true;
    setAccounts(filled);
  }

  const enriched = useMemo(() => {
    return accounts.map((a) => {
      const status = coverageStatus(a, people);
      return { ...a, status, target: TARGET_COVERAGE[a.tier], missing: missingRoles(a, people) };
    });
  }, [accounts, people]);

  const filtered = enriched.filter((a) => {
    if (filterTier !== "All" && a.tier !== filterTier) return false;
    if (filterStatus !== "All" && a.status !== filterStatus) return false;
    return true;
  });

  const gapCount = enriched.filter((a) => a.status === "gap").length;
  const underCount = enriched.filter((a) => a.status === "under").length;
  const okCount = enriched.filter((a) => a.status === "ok" || a.status === "over").length;

  const peopleLoad = useMemo(() => {
    const load = {};
    people.forEach((p) => (load[p.id] = 0));
    accounts.forEach((a) => a.assignedIds.forEach((id) => (load[id] = (load[id] || 0) + 1)));
    return load;
  }, [people, accounts]);

  function toggleAssign(accountId, personId) {
    setAccounts((prev) =>
      prev.map((a) => {
        if (a.id !== accountId) return a;
        const has = a.assignedIds.includes(personId);
        return {
          ...a,
          assignedIds: has
            ? a.assignedIds.filter((id) => id !== personId)
            : [...a.assignedIds, personId],
          manualIds: has
            ? a.manualIds.filter((id) => id !== personId)
            : [...a.manualIds, personId],
        };
      })
    );
  }

  function addPerson() {
    if (!newPersonName.trim()) return;
    setPeople((prev) => [
      ...prev,
      { id: `p${Date.now()}`, name: newPersonName.trim(), role: newPersonRole },
    ]);
    setNewPersonName("");
    setShowAddPerson(false);
  }

  function addAccount() {
    if (!newAccountName.trim()) return;
    setAccounts((prev) => [
      ...prev,
      { id: `a${Date.now()}`, name: newAccountName.trim(), tier: newAccountTier, assignedIds: [], manualIds: [] },
    ]);
    setNewAccountName("");
    setShowAddAccount(false);
  }

  function removeAccount(id) {
    setAccounts((prev) => prev.filter((a) => a.id !== id));
  }

  function removePerson(id) {
    setPeople((prev) => prev.filter((p) => p.id !== id));
    setAccounts((prev) =>
      prev.map((a) => ({ ...a, assignedIds: a.assignedIds.filter((pid) => pid !== id) }))
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans">
      <div className="max-w-5xl mx-auto px-4 py-8 sm:px-6">
        {/* Header */}
        <header className="mb-6">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-medium tracking-wide uppercase mb-1">
            <Building2 size={14} />
            ABM Coverage
          </div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-slate-50 tracking-tight">
            Account staffing
          </h1>
          <p className="text-slate-500 text-sm mt-1">
            Who's covering what, and where the gaps are.
          </p>
        </header>

        {/* Auto-assign controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6 bg-slate-900 border border-slate-800 rounded-lg px-4 py-3">
          <div className="flex items-center gap-2">
            <Zap size={15} className={autoEnabled ? "text-indigo-400" : "text-slate-600"} />
            <div>
              <div className="text-sm text-slate-200">Auto-assign</div>
              <div className="text-[11px] text-slate-500">
                Fills open required roles by lowest workload. Manual picks are never overridden.
              </div>
              {lastAutoCount > 0 && (
                <div className="text-[11px] text-emerald-400 mt-0.5">
                  Just filled {lastAutoCount} {lastAutoCount === 1 ? "slot" : "slots"}.
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={runAutoAssignNow}
              className="text-xs font-medium bg-indigo-500 hover:bg-indigo-400 text-white rounded px-3 py-1.5 transition-colors whitespace-nowrap"
            >
              Run now
            </button>
            <button
              role="switch"
              aria-checked={autoEnabled}
              onClick={() => setAutoEnabled((v) => !v)}
              className={`relative w-9 h-5 rounded-full transition-colors ${
                autoEnabled ? "bg-indigo-500" : "bg-slate-700"
              }`}
            >
              <span
                className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                  autoEnabled ? "translate-x-4" : "translate-x-0"
                }`}
              />
            </button>
          </div>
        </div>

        {unfilledSlots.length > 0 && (
          <div className="flex items-start gap-2 text-xs text-amber-300 bg-amber-500/10 border border-amber-500/20 rounded-lg px-3 py-2 mb-6">
            <AlertTriangle size={13} className="mt-0.5 shrink-0" />
            <span>
              Couldn't auto-fill {unfilledSlots.length} {unfilledSlots.length === 1 ? "role" : "roles"} — no
              available person with the right role:{" "}
              {unfilledSlots.map((s, i) => (
                <span key={i}>
                  {s.accountName} needs {s.role}
                  {i < unfilledSlots.length - 1 ? ", " : ""}
                </span>
              ))}
            </span>
          </div>
        )}

        {/* Summary strip */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          <SummaryCard label="Unstaffed" count={gapCount} colorClass="text-rose-400" dotClass="bg-rose-500" />
          <SummaryCard label="Short-staffed" count={underCount} colorClass="text-amber-400" dotClass="bg-amber-500" />
          <SummaryCard label="Covered" count={okCount} colorClass="text-emerald-400" dotClass="bg-emerald-500" />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <FilterPills
            options={["All", ...TIERS]}
            value={filterTier}
            onChange={setFilterTier}
          />
          <span className="text-slate-700 hidden sm:inline">·</span>
          <FilterPills
            options={["All", "gap", "under", "ok", "over"]}
            labels={{ All: "All", gap: "Unstaffed", under: "Short", ok: "Covered", over: "Over" }}
            value={filterStatus}
            onChange={setFilterStatus}
          />
        </div>

        {/* Account list */}
        <div className="space-y-2 mb-10">
          {filtered.length === 0 && (
            <div className="text-slate-600 text-sm py-10 text-center border border-dashed border-slate-800 rounded-lg">
              No accounts match these filters.
            </div>
          )}
          {filtered.map((a) => {
            const style = STATUS_STYLES[a.status];
            const fillPct = Math.min(100, (a.assignedIds.length / a.target) * 100);
            return (
              <div
                key={a.id}
                className="group bg-slate-900 border border-slate-800 rounded-lg px-4 py-3 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-100 truncate">{a.name}</span>
                      <span className="text-[11px] text-slate-500 border border-slate-700 rounded px-1.5 py-0.5 leading-none whitespace-nowrap">
                        {a.tier}
                      </span>
                    </div>

                    {/* Coverage bar — signature element */}
                    <div className="mt-2 flex items-center gap-2">
                      <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden flex">
                        {Array.from({ length: a.target }).map((_, i) => (
                          <div
                            key={i}
                            className={`flex-1 border-r border-slate-950 last:border-r-0 ${
                              i < a.assignedIds.length ? style.bar : "bg-slate-800"
                            }`}
                          />
                        ))}
                        {a.assignedIds.length > a.target && (
                          <div className="flex-1 bg-indigo-400" />
                        )}
                      </div>
                      <span className={`text-xs font-medium ${style.text} whitespace-nowrap`}>
                        {a.assignedIds.length}/{a.target}
                      </span>
                    </div>

                    {/* Assigned avatars */}
                    <div className="mt-2 flex items-center gap-1.5 flex-wrap">
                      {a.assignedIds.length === 0 ? (
                        <span className="text-xs text-slate-600 italic">No one assigned</span>
                      ) : (
                        a.assignedIds.map((pid) => {
                          const p = personById[pid];
                          if (!p) return null;
                          const isManual = a.manualIds.includes(pid);
                          return (
                            <span
                              key={pid}
                              className="text-xs bg-slate-800 text-slate-300 rounded-full px-2 py-0.5 flex items-center gap-1"
                            >
                              {isManual ? (
                                <Lock size={10} className="text-slate-500" />
                              ) : (
                                <Zap size={10} className="text-indigo-400" />
                              )}
                              {p.name}
                              <span className="text-slate-500"> · {p.role}</span>
                            </span>
                          );
                        })
                      )}
                      {a.missing.length > 0 && (
                        <span className="text-xs text-rose-400/80 italic">
                          needs: {a.missing.join(", ")}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => setAssignOpenFor(assignOpenFor === a.id ? null : a.id)}
                      className="text-xs font-medium text-indigo-400 hover:text-indigo-300 px-2 py-1 rounded hover:bg-slate-800 transition-colors whitespace-nowrap"
                    >
                      Assign
                    </button>
                    <button
                      onClick={() => removeAccount(a.id)}
                      aria-label={`Remove ${a.name}`}
                      className="text-slate-600 hover:text-rose-400 p-1 rounded hover:bg-slate-800 transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>

                {/* Assign panel */}
                {assignOpenFor === a.id && (
                  <div className="mt-3 pt-3 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                    {people.map((p) => {
                      const checked = a.assignedIds.includes(p.id);
                      return (
                        <button
                          key={p.id}
                          onClick={() => toggleAssign(a.id, p.id)}
                          className={`flex items-center gap-1.5 text-xs rounded px-2 py-1.5 text-left transition-colors ${
                            checked
                              ? "bg-indigo-500/15 text-indigo-300 border border-indigo-500/30"
                              : "bg-slate-800/60 text-slate-400 border border-transparent hover:border-slate-700"
                          }`}
                        >
                          {checked ? <CheckCircle2 size={13} /> : <Circle size={13} />}
                          <span className="truncate">{p.name}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Add account */}
        <div className="mb-12">
          {showAddAccount ? (
            <div className="flex flex-wrap items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg p-3">
              <input
                autoFocus
                value={newAccountName}
                onChange={(e) => setNewAccountName(e.target.value)}
                placeholder="Account name"
                className="flex-1 min-w-[140px] bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                onKeyDown={(e) => e.key === "Enter" && addAccount()}
              />
              <select
                value={newAccountTier}
                onChange={(e) => setNewAccountTier(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                {TIERS.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
              <button
                onClick={addAccount}
                className="text-sm font-medium bg-indigo-500 hover:bg-indigo-400 text-white rounded px-3 py-1.5 transition-colors"
              >
                Add
              </button>
              <button
                onClick={() => setShowAddAccount(false)}
                className="text-sm text-slate-500 hover:text-slate-300 px-2 py-1.5"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowAddAccount(true)}
              className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-indigo-400 transition-colors"
            >
              <Plus size={15} /> Add account
            </button>
          )}
        </div>

        {/* Team roster */}
        <section>
          <div className="flex items-center gap-2 text-slate-400 text-xs font-medium tracking-wide uppercase mb-3">
            <Users size={14} />
            Team roster
          </div>
          <div className="space-y-1.5">
            {people.map((p) => {
              const load = peopleLoad[p.id] || 0;
              return (
                <div
                  key={p.id}
                  className="group flex items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-sm text-slate-200 truncate">{p.name}</span>
                    <span className="text-[11px] text-slate-500 border border-slate-700 rounded px-1.5 py-0.5 leading-none whitespace-nowrap">
                      {p.role}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span
                      className={`text-xs ${
                        load === 0 ? "text-slate-600" : load > 4 ? "text-amber-400" : "text-slate-500"
                      }`}
                    >
                      {load} {load === 1 ? "account" : "accounts"}
                    </span>
                    <button
                      onClick={() => removePerson(p.id)}
                      aria-label={`Remove ${p.name}`}
                      className="text-slate-600 hover:text-rose-400 p-1 rounded hover:bg-slate-800 transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                    >
                      <X size={13} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-3">
            {showAddPerson ? (
              <div className="flex flex-wrap items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg p-3">
                <input
                  autoFocus
                  value={newPersonName}
                  onChange={(e) => setNewPersonName(e.target.value)}
                  placeholder="Name"
                  className="flex-1 min-w-[140px] bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                  onKeyDown={(e) => e.key === "Enter" && addPerson()}
                />
                <select
                  value={newPersonRole}
                  onChange={(e) => setNewPersonRole(e.target.value)}
                  className="bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  {ROLES.map((r) => (
                    <option key={r}>{r}</option>
                  ))}
                </select>
                <button
                  onClick={addPerson}
                  className="text-sm font-medium bg-indigo-500 hover:bg-indigo-400 text-white rounded px-3 py-1.5 transition-colors"
                >
                  Add
                </button>
                <button
                  onClick={() => setShowAddPerson(false)}
                  className="text-sm text-slate-500 hover:text-slate-300 px-2 py-1.5"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowAddPerson(true)}
                className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-indigo-400 transition-colors"
              >
                <Plus size={15} /> Add person
              </button>
            )}
          </div>
        </section>

        {gapCount > 0 && (
          <div className="mt-10 flex items-start gap-2 text-xs text-slate-600 border-t border-slate-800 pt-4">
            <AlertTriangle size={13} className="mt-0.5 text-rose-500/70 shrink-0" />
            <span>
              {gapCount} {gapCount === 1 ? "account has" : "accounts have"} no one assigned. Required
              roles — Tier 1: {ROLE_REQUIREMENTS["Tier 1"].join(", ")}; Tier 2:{" "}
              {ROLE_REQUIREMENTS["Tier 2"].join(", ")}; Tier 3: {ROLE_REQUIREMENTS["Tier 3"].join(", ")}.
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

function SummaryCard({ label, count, colorClass, dotClass }) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-3 sm:px-4">
      <div className="flex items-center gap-1.5 mb-1">
        <span className={`w-1.5 h-1.5 rounded-full ${dotClass}`} />
        <span className="text-[11px] text-slate-500 uppercase tracking-wide">{label}</span>
      </div>
      <div className={`text-2xl font-semibold ${colorClass}`}>{count}</div>
    </div>
  );
}

function FilterPills({ options, labels, value, onChange }) {
  return (
    <div className="flex items-center gap-1 flex-wrap">
      {options.map((opt) => (
        <button
          key={opt}
          onClick={() => onChange(opt)}
          className={`text-xs rounded-full px-2.5 py-1 transition-colors ${
            value === opt
              ? "bg-indigo-500 text-white"
              : "bg-slate-900 text-slate-500 border border-slate-800 hover:border-slate-700"
          }`}
        >
          {labels ? labels[opt] : opt}
        </button>
      ))}
    </div>
  );
}
