# ABM Staffing Tracker

Tracks which team member is covering which account, auto-fills open roles, and flags gaps.

## Run locally

```bash
npm install
npm run dev
```

Opens at http://localhost:5173

## Build for production

```bash
npm run build
npm run preview   # preview the production build locally
```

The build output goes to `dist/`.

## Deploy

**GitHub:** push this folder as a repo (`git init`, `git add .`, `git commit`, `git push`).

**Vercel / Netlify:** connect the GitHub repo, or drag-and-drop the `dist/` folder after running `npm run build`.
- Build command: `npm run build`
- Output directory: `dist`

## Editing your team and accounts

Open `src/App.jsx`:

- **Team roster**: edit the `initialPeople` array (name + role)
- **Accounts**: edit the `initialAccounts` array (name + tier)
- **Roles**: edit the `ROLES` array
- **What each tier requires**: edit `ROLE_REQUIREMENTS`

Everything else (auto-assign logic, coverage bars, filters) adjusts automatically based on those edits.

## Notes

- Data lives in memory only — refreshing the page resets it back to the values in `App.jsx`. Ask if you want it to persist to a real database instead.
